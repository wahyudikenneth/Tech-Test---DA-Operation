# app.py
from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
import json

# Load the trained model
import joblib
model = joblib.load("model.joblib")

# Initialize FastAPI app
app = FastAPI()

# Input data model for API request
class InputData(BaseModel):
    fixed_acidity: float
    volatile_acidity: float
    citric_acid: float
    chlorides: float
    free_sulfur_dioxide: float
    total_sulfur_dioxide: float
    density: float
    pH: float
    sulphates: float
    alcohol: float
    residual_sugar: float

# Function to preprocess the data
def preprocess_data(data: pd.DataFrame):
    # Drop columns only if they exist in the DataFrame, avoid KeyError
    cols_to_drop = ['fixed_acidity', 'residual_sugar', 'free_sulfur_dioxide', 'total_sulfur_dioxide', 'pH', 'sulphates']
    existing_cols_to_drop = [col for col in cols_to_drop if col in data.columns]
    data = data.drop(existing_cols_to_drop, axis=1)

    # Log-transform and scale data
    for i in data.columns:
        data[i] = np.log1p(data[i])
    for i in data.columns:
        data[i] = StandardScaler().fit_transform(data[i].values.reshape(len(data), 1))
    return data

# API endpoint for prediction
@app.post("/predict/")
async def predict(data: InputData):
    # Convert input data into DataFrame
    input_data = pd.DataFrame([data.dict()])
    
    # Preprocess the input data
    processed_data = preprocess_data(input_data)

    # Make predictions
    prediction = model.predict(processed_data)
    prediction = np.round(prediction)[0]
    
    # Return prediction
    return {"prediction": prediction}

# Run the app with: uvicorn app:app --host 0.0.0.0 --port 8000