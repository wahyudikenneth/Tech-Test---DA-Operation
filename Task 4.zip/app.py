# app.py
from fastapi import FastAPI, Request
from pydantic import BaseModel
import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
import logging
import time
from prometheus_fastapi_instrumentator import Instrumentator

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("api.log"),
        logging.StreamHandler()
    ]
)

# Load the model
model = joblib.load("model.joblib")

app = FastAPI()

# Instrument the app
Instrumentator().instrument(app).expose(app)

class InputData(BaseModel):
    fixed_acidity: float
    volatile_acidity: float
    citric_acid: float
    chlorides: float
    free_sulfur_dioxide: float
    total_sulfur_dioxide: float
    density: float
    pH: float
    sulphates: float
    alcohol: float
    residual_sugar: float

def preprocess_data(data: pd.DataFrame):
    cols_to_drop = ['fixed_acidity', 'residual_sugar', 'free_sulfur_dioxide', 'total_sulfur_dioxide', 'pH', 'sulphates']
    existing_cols_to_drop = [col for col in cols_to_drop if col in data.columns]
    data = data.drop(existing_cols_to_drop, axis=1)
    for i in data.columns:
        data[i] = np.log1p(data[i])
    for i in data.columns:
        data[i] = StandardScaler().fit_transform(data[i].values.reshape(len(data), 1))
    return data

@app.post("/predict/")
async def predict(data: InputData, request: Request):
    start_time = time.time()
    input_data = pd.DataFrame([data.dict()])
    logging.info(f"Request from {request.client.host}: {input_data.to_dict()}")
    try:
        processed_data = preprocess_data(input_data)
        prediction = model.predict(processed_data)
        prediction = np.round(prediction)[0]
        latency = time.time() - start_time
        logging.info(f"Prediction: {prediction}, Latency: {latency:.3f}s")
        return {"prediction": int(prediction)}
    except Exception as e:
        latency = time.time() - start_time
        logging.error(f"Prediction failed: {e}, Latency: {latency:.3f}s")
        return {"error": str(e)}